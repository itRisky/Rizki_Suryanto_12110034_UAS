nama: Rizki Suryanto 
nim: 12110034